package com.example.licence.helloworld;

import java.util.List;

/**
 * Created by licence on 13/03/2018.
 */

public class ListStat {

    private List alContact;

    public ListStat(List alContact) {
        this.alContact = alContact;
    }
}
