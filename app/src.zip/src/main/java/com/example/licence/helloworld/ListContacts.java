package com.example.licence.helloworld;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.provider.Contacts;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by licence on 13/03/2018.
 */

public class ListContacts {


}
