package com.example.licence.helloworld;

import android.app.Service;


/**
 * Created by licence on 13/03/2018.
 */

public class SMSServiceCustom  {
}
